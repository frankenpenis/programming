// Tyler J Groves
// COMSC1033 MWF 11AM

public class MyFirstProgram 
{

	public static void main(String[] args) 
	{
		System.out.println( "Programming is not a spectator sport!");
		
		System.exit ( 0 );

	}

}
