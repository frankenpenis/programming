//This program should create a run time errors
//Why is this an error?
public class Debug3
{
	public static void main(String [] args)
	{
		System.out.println("My first Java program.");
		System.out.println("The sum of 2 and 3 = " + 5);
		System.out.println("The sum of 7 and 8 = " + (7+8));
	}//end main
	
}//end program