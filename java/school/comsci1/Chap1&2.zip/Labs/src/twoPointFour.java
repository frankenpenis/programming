/* Tyler J Groves
 * COMSC1033 MWF 11AM
 * Homework 2.4
 */ 
 
public class twoPointFour
{
	public static void main(String [] args)
	{
		// Define Variables
		int a = 180;
		int b = 197;
		int result;
		double divA = 180;
		double divB = 197;
		double divResult;
		
		// Output
		result = a + b;
		System.out.println("The number 180 plus the number 197 is " + result);
		
		result = a - b;
		System.out.println("The number 180 minus the number 197 is " + result);
		
		result = a * b;
		System.out.println("The number 180 multiplied by the number 197 is " + result);
		
		divResult = divA / divB;
		System.out.println("The number 180 divided by the number 197 is " + divResult);
	}
}
