/* 
 * Tyler J Groves
 * COMSC1033 MWF 11AM
 * Chapter 2 
 */ 

public class Test
{
	public static void main( String [] args ) 
	{
		// Define Variables
		int myAge = 21;
		int yourAge = 18;
		int resultAge;
		resultAge = myAge - yourAge;
	
		//Output
		System.out.println("I am " + resultAge + " years older than you.");
	}

}
